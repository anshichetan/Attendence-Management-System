<?php
session_start();
session_destroy();
header('location: /online-attendance-management-system-1.0-master/index.php');
?>