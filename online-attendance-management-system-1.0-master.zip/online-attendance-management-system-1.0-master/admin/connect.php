<?php

$host = "localhost";
$username = "root";
$pass = "";

$con = mysqli_connect($host, $username, $pass, "attsystem");
// mysqli_connect('localhost','root','') or die('Cannot connect to server');
// mysqli_select_db('attsystem') or die ('Cannot found database');

?>